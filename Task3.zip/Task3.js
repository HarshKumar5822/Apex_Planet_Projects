function fetchJoke() {
  fetch("https://official-joke-api.appspot.com/jokes/random")
    .then(response => response.json())
    .then(data => {
      let joke = data.setup + " " + data.punchline;
      document.getElementById("joke").innerText = joke;
    })
    .catch(() => {
      document.getElementById("joke").innerText = "Failed to load joke.";
    });
}

let questions = [
  {
    question: "What is the capital of India?",
    options: ["Mumbai", "New Delhi", "Kolkata", "Chennai"],
    answer: "New Delhi"
  },
  {
    question: "Which language runs in the browser?",
    options: ["Java", "Python", "JavaScript", "C++"],
    answer: "JavaScript"
  },
  {
    question: "Which HTML tag is used for a paragraph?",
    options: ["<div>", "<p>", "<h1>", "<span>"],
    answer: "<p>"
  }
];

let current = 0;
let score = 0;

function loadQuestion() {
  let q = questions[current];
  document.getElementById("question").innerText = q.question;

  let optionsBox = document.getElementById("options");
  optionsBox.innerHTML = "";

  q.options.forEach(option => {
    let btn = document.createElement("button");
    btn.innerText = option;
    btn.onclick = () => checkAnswer(option);
    optionsBox.appendChild(btn);
  });
}

function checkAnswer(selected) {
  if (selected === questions[current].answer) {
    score++;
  }
  document.querySelectorAll("#options button").forEach(btn => {
    btn.disabled = true;
    if (btn.innerText === questions[current].answer) {
      btn.style.backgroundColor = "green";
    } else {
      btn.style.backgroundColor = "red";
    }
  });
}

function nextQuestion() {
  current++;
  if (current < questions.length) {
    loadQuestion();
  } else {
    document.getElementById("quiz-box").innerHTML = `<h3>Quiz Finished!</h3><p>You scored ${score} out of ${questions.length}</p>`;
  }
}

loadQuestion();
