function showMessage() {
    alert("Hello! I am Harsh, This is Alert message!");
}
