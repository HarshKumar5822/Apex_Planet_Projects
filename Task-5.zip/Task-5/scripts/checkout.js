function getCart(){return JSON.parse(localStorage.getItem('cart')||'[]')}

function renderSummary(){
  const cart=getCart();
  const el=document.getElementById('order-summary');
  const btn=document.querySelector('#checkout-form .btn');
  if(!el)return;
  if(cart.length===0){
    el.innerHTML='<p>Your cart is empty.</p>';
    if(btn) btn.disabled = true;
    return;
  }
  if(btn) btn.disabled = false;
  el.innerHTML = `<div class="checkout-summary">${cart.map(ci=>{
    const p=window.products.find(x=>x.id===ci.id);
    return `<div class="checkout-card">
      <img src="${p.image}" alt="${p.name}">
      <div class="checkout-info">
        <strong>${p.name}</strong>
        <span>Qty: ${ci.qty}</span>
        <span>Price: ₹${p.price.toLocaleString('en-IN')}</span>
        <span>Subtotal: ₹${(p.price*ci.qty).toLocaleString('en-IN')}</span>
      </div>
    </div>`;
  }).join('')}</div><div class="checkout-total">Total: ₹${cart.reduce((a,c)=>a+c.qty*window.products.find(p=>p.id===c.id).price,0).toLocaleString('en-IN')}</div>`;
}

renderSummary();

const form = document.getElementById('checkout-form');
const message = document.getElementById('checkout-message');

form.onsubmit = function(e){
  e.preventDefault();
  // Validate
  const name = form.querySelector('input[placeholder="Name"]');
  const email = form.querySelector('input[placeholder="Email"]');
  const address = form.querySelector('input[placeholder="Address"]');
  let valid = true;
  [name, email, address].forEach(input => {
    if(!input.value.trim()){
      input.style.borderColor = '#e74c3c';
      valid = false;
    } else {
      input.style.borderColor = '';
    }
  });
  if(!valid) return;
  // Show spinner
  message.innerHTML = '<span class="checkout-spinner"></span>Placing your order...';
  form.querySelector('.btn').disabled = true;
  setTimeout(()=>{
    localStorage.removeItem('cart');
    renderSummary();
    form.reset();
    message.innerHTML = '🎉 Order placed successfully! You will receive a confirmation email soon.';
    form.querySelector('.btn').disabled = false;
  }, 1500);
};

// Live validation feedback
form.querySelectorAll('input').forEach(input => {
  input.addEventListener('input', function(){
    if(this.value.trim()){
      this.style.borderColor = '';
    }
  });
}); 