function setCart(cart){localStorage.setItem('cart',JSON.stringify(cart));updateCartCount();}
function updateQty(id,qty){let cart=getCart();const item=cart.find(i=>i.id===id);if(item){item.qty=qty;if(item.qty<1)cart=cart.filter(i=>i.id!==id)}setCart(cart);renderCart()}
function removeItem(id){let cart=getCart().filter(i=>i.id!==id);setCart(cart);renderCart()}
function renderCart(){
  const cart=getCart();
  const items=document.getElementById('cart-items');
  const total=document.getElementById('cart-total');
  if(!items||!total)return;
  if(cart.length===0){items.innerHTML='<p>Your cart is empty.</p>';total.textContent='';return}
  items.innerHTML=cart.map(ci=>{
    const p=window.products.find(x=>x.id===ci.id);
    return `<div class="cart-item">
      <img src="${p.image}" alt="${p.name}" loading="lazy" style="width:100px;height:100px;object-fit:cover;">
      <div class="cart-info">
        <h3>${p.name}</h3>
        <p>₹${p.price.toLocaleString('en-IN')}</p>
      </div>
      <div class="cart-actions">
        <button class="qty-btn" data-id="${ci.id}" data-action="decrement">−</button>
        <input type="number" min="1" value="${ci.qty}" data-id="${ci.id}">
        <button class="qty-btn" data-id="${ci.id}" data-action="increment">+</button>
        <button data-id="${ci.id}">Remove</button>
      </div>
    </div>`
  }).join('');
  items.querySelectorAll('input[type=number]').forEach(inp=>{
    inp.onchange=()=>updateQty(Number(inp.dataset.id),Number(inp.value))
  });
  items.querySelectorAll('button.qty-btn').forEach(btn=>{
    btn.onclick=()=>{
      const id=Number(btn.dataset.id);
      const inp=items.querySelector(`input[data-id='${id}']`);
      let val=Number(inp.value)||1;
      if(btn.dataset.action==='increment') val++;
      if(btn.dataset.action==='decrement') val=Math.max(1,val-1);
      updateQty(id,val);
    }
  });
  items.querySelectorAll('button:not(.qty-btn)').forEach(btn=>{
    btn.onclick=()=>removeItem(Number(btn.dataset.id))
  });
  const sum=cart.reduce((a,c)=>a+c.qty*window.products.find(p=>p.id===c.id).price,0);
  total.textContent='Total: ₹'+sum.toLocaleString('en-IN')
}
renderCart();

if(document.readyState === 'loading'){
  document.addEventListener('DOMContentLoaded', updateCartCount);
}else{
  updateCartCount();
} 