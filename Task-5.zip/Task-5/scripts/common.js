// Common utility functions for cart badge
function getCart(){
  return JSON.parse(localStorage.getItem('cart')||'[]');
}
function updateCartCount(){
  const cart = getCart();
  let count = 0;
  cart.forEach(item => count += item.qty);
  let navCart = document.querySelector('a[href="cart.html"]');
  if(navCart){
    let badge = navCart.querySelector('.cart-count');
    if(!badge){
      badge = document.createElement('span');
      badge.className = 'cart-count';
      badge.style = 'background:#e74c3c;color:#fff;border-radius:50%;padding:2px 7px;font-size:0.8em;margin-left:5px;';
      navCart.appendChild(badge);
    }
    badge.textContent = count > 0 ? count : '';
  }
}
function getWishlist(){
  return JSON.parse(localStorage.getItem('wishlist')||'[]');
}
function updateWishlistCount(){
  const wishlist = getWishlist();
  let count = wishlist.length;
  let navWishlist = document.querySelector('a[href="wishlist.html"]');
  if(navWishlist){
    let badge = navWishlist.querySelector('.wishlist-count');
    if(!badge){
      badge = document.createElement('span');
      badge.className = 'wishlist-count';
      badge.style = 'background:#e74c3c;color:#fff;border-radius:50%;padding:2px 7px;font-size:0.8em;margin-left:5px;';
      navWishlist.appendChild(badge);
    }
    badge.textContent = count > 0 ? count : '';
  }
}
if(document.readyState === 'loading'){
  document.addEventListener('DOMContentLoaded', updateCartCount);
  document.addEventListener('DOMContentLoaded', updateWishlistCount);
  document.addEventListener('DOMContentLoaded', function() {
    var navToggle = document.getElementById('nav-toggle');
    var mainNav = document.getElementById('main-nav');
    if (navToggle && mainNav) {
      navToggle.addEventListener('click', function() {
        mainNav.classList.toggle('active');
      });
    }
  });
}else{
  updateCartCount();
  updateWishlistCount();
} 