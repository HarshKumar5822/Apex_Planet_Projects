// Wishlist logic for aswa

function getWishlist() {
    return JSON.parse(localStorage.getItem('wishlist') || '[]');
}

function setWishlist(wishlist) {
    localStorage.setItem('wishlist', JSON.stringify(wishlist));
    if(typeof updateWishlistCount === 'function') updateWishlistCount();
}

function addToWishlist(id) {
    let wishlist = getWishlist();
    if (!wishlist.includes(id)) {
        wishlist.push(id);
        setWishlist(wishlist);
        renderWishlist();
    }
    if(typeof updateWishlistCount === 'function') updateWishlistCount();
}

function removeFromWishlist(id) {
    let wishlist = getWishlist().filter(wid => wid !== id);
    setWishlist(wishlist);
    renderWishlist();
    if(typeof updateWishlistCount === 'function') updateWishlistCount();
}

function renderWishlist() {
    const wishlist = getWishlist();
    const items = document.getElementById('wishlist-items');
    const count = document.getElementById('wishlist-count');
    if (!items || !count) return;
    if (wishlist.length === 0) {
        items.innerHTML = '<p>Your wishlist is empty.</p>';
        count.textContent = '';
        if(typeof updateWishlistCount === 'function') updateWishlistCount();
        return;
    }
    items.innerHTML = `<div class="wishlist-grid">${wishlist.map(id => {
        const p = window.products.find(x => x.id === id);
        return `<div class="wishlist-card">
            <img src="${p.image}" alt="${p.name}">
            <h3>${p.name}</h3>
            <p>₹${p.price.toLocaleString('en-IN')}</p>
            <div class="wishlist-actions">
                <button data-id="${p.id}">Remove</button>
            </div>
        </div>`;
    }).join('')}</div>`;
    items.querySelectorAll('button').forEach(btn => {
        btn.onclick = () => removeFromWishlist(Number(btn.dataset.id));
    });
    count.textContent = 'Total items: ' + wishlist.length;
    if(typeof updateWishlistCount === 'function') updateWishlistCount();
}

document.addEventListener('DOMContentLoaded', renderWishlist); 