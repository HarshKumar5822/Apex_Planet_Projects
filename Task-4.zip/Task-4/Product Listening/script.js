// Sample product data
const products = [
  { id: 1, name: "Wireless Headphones", category: "Electronics", price: 120, rating: 4.5 },
  { id: 2, name: "Running Shoes", category: "Footwear", price: 80, rating: 4.2 },
  { id: 3, name: "Coffee Maker", category: "Home Appliances", price: 60, rating: 4.0 },
  { id: 4, name: "Smartphone", category: "Electronics", price: 350, rating: 4.8 },
  { id: 5, name: "T-shirt", category: "Clothing", price: 20, rating: 3.9 },
  { id: 6, name: "Blender", category: "Home Appliances", price: 45, rating: 4.1 },
  { id: 7, name: "Sandals", category: "Footwear", price: 25, rating: 3.8 },
  { id: 8, name: "Jeans", category: "Clothing", price: 40, rating: 4.3 },
  { id: 9, name: "Tablet", category: "Electronics", price: 220, rating: 4.4 },
  { id: 10, name: "Jacket", category: "Clothing", price: 60, rating: 4.6 },
];

// Populate category filter
const categorySet = new Set(products.map(p => p.category));
const categorySelect = document.getElementById('category');
categorySet.forEach(cat => {
  const opt = document.createElement('option');
  opt.value = cat;
  opt.textContent = cat;
  categorySelect.appendChild(opt);
});

// Filtering and sorting logic
function renderProducts() {
  const selectedCategory = categorySelect.value;
  const minPrice = parseFloat(document.getElementById('minPrice').value) || 0;
  const maxPrice = parseFloat(document.getElementById('maxPrice').value) || Infinity;
  const sortValue = document.getElementById('sort').value;

  let filtered = products.filter(p =>
    (selectedCategory === 'all' || p.category === selectedCategory) &&
    p.price >= minPrice &&
    p.price <= maxPrice
  );

  if (sortValue === 'high') {
    filtered.sort((a, b) => b.rating - a.rating);
  } else if (sortValue === 'low') {
    filtered.sort((a, b) => a.rating - b.rating);
  }

  const productList = document.getElementById('productList');
  productList.innerHTML = '';
  if (filtered.length === 0) {
    productList.innerHTML = '<p>No products found.</p>';
    return;
  }
  filtered.forEach(p => {
    const div = document.createElement('div');
    div.className = 'product';
    div.innerHTML = `
      <div class="product-title">${p.name}</div>
      <div class="product-category">${p.category}</div>
      <div class="product-price">₹${p.price.toFixed(2)}</div>
      <div class="product-rating">${'★'.repeat(Math.round(p.rating))} (${p.rating})</div>
    `;
    productList.appendChild(div);
  });
}

// Event listeners
// Wait for DOM to be ready
window.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.filters select, .filters input').forEach(el => {
    el.addEventListener('input', renderProducts);
    el.addEventListener('change', renderProducts);
  });
  renderProducts();
}); 