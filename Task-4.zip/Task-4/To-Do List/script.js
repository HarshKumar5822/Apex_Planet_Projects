// Select elements
const taskInput = document.getElementById('task-input');
const addTaskBtn = document.getElementById('add-task-btn');
const taskList = document.getElementById('task-list');
const saveBtn = document.getElementById('save-btn');

// Load tasks from localStorage
let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

function saveTasks() {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function renderTasks() {
    taskList.innerHTML = '';
    tasks.forEach((task, idx) => {
        const li = document.createElement('li');
        li.className = 'task-item' + (task.completed ? ' completed' : '');

        if (task.editing) {
            // Editing mode
            const input = document.createElement('input');
            input.type = 'text';
            input.value = task.text;
            input.className = 'edit-input';
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') saveEdit(idx, input.value);
                if (e.key === 'Escape') cancelEdit(idx);
            });
            li.appendChild(input);

            const saveBtn = document.createElement('button');
            saveBtn.className = 'edit-btn';
            saveBtn.textContent = 'Save';
            saveBtn.onclick = () => saveEdit(idx, input.value);
            li.appendChild(saveBtn);

            const cancelBtn = document.createElement('button');
            cancelBtn.className = 'cancel-btn';
            cancelBtn.textContent = 'Cancel';
            cancelBtn.onclick = () => cancelEdit(idx);
            li.appendChild(cancelBtn);
        } else {
            // Normal mode
            const span = document.createElement('span');
            span.className = 'task-text';
            span.textContent = task.text;
            span.onclick = () => toggleComplete(idx);
            li.appendChild(span);

            const editBtn = document.createElement('button');
            editBtn.className = 'edit-btn';
            editBtn.textContent = 'Edit';
            editBtn.onclick = () => editTask(idx);
            li.appendChild(editBtn);

            const cancelBtn = document.createElement('button');
            cancelBtn.className = 'cancel-btn';
            cancelBtn.textContent = 'Cancel';
            cancelBtn.onclick = () => deleteTask(idx);
            li.appendChild(cancelBtn);
        }
        taskList.appendChild(li);
    });
}

function addTask() {
    const text = taskInput.value.trim();
    if (text) {
        tasks.push({ text, completed: false });
        saveTasks();
        renderTasks();
        taskInput.value = '';
        taskInput.focus();
    }
}

function deleteTask(idx) {
    tasks.splice(idx, 1);
    saveTasks();
    renderTasks();
}

function toggleComplete(idx) {
    tasks[idx].completed = !tasks[idx].completed;
    saveTasks();
    renderTasks();
}

function editTask(idx) {
    tasks = tasks.map((task, i) => ({ ...task, editing: i === idx }));
    renderTasks();
    // Focus the input after rendering
    setTimeout(() => {
        const input = document.querySelector('.edit-input');
        if (input) input.focus();
    }, 0);
}

function saveEdit(idx, newText) {
    if (newText.trim()) {
        tasks[idx].text = newText.trim();
    }
    tasks[idx].editing = false;
    saveTasks();
    renderTasks();
}

function cancelEdit(idx) {
    tasks[idx].editing = false;
    renderTasks();
}

addTaskBtn.addEventListener('click', addTask);
taskInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addTask();
});

saveBtn.addEventListener('click', () => {
    let content = tasks.map((task, i) => `${i + 1}. ${task.text}`).join('\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'todo-list.txt';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 0);
});

// Initial render
renderTasks(); 