function validateForm() {
  let name = document.getElementById("name").value;
  let email = document.getElementById("email").value;

  if (name === "" || email === "") {
    alert("All fields are required");
    return false;
  }

  if (!email.includes("@")) {
    alert("Enter a valid email");
    return false;
  }

  alert("Form submitted successfully!");
  return true;
}

function addTask() {
  let taskText = document.getElementById("taskInput").value.trim();
  if (taskText === "") return;

  let li = document.createElement("li");
  li.className = "task-item";

  let taskContent = document.createElement("span");
  taskContent.innerText = taskText;

  let inputEdit = document.createElement("input");
  inputEdit.type = "text";
  inputEdit.style.display = "none";

  let btnContainer = document.createElement("div");
  btnContainer.className = "task-buttons";

  let editBtn = document.createElement("button");
  editBtn.innerText = "Edit";
  editBtn.className = "edit-btn";
  editBtn.onclick = () => {
    inputEdit.value = taskContent.innerText;
    taskContent.style.display = "none";
    inputEdit.style.display = "inline";
    editBtn.style.display = "none";
    saveBtn.style.display = "inline";
    cancelBtn.style.display = "inline";
  };

  let saveBtn = document.createElement("button");
  saveBtn.innerText = "Save";
  saveBtn.className = "save-btn";
  saveBtn.style.display = "none";
  saveBtn.onclick = () => {
    taskContent.innerText = inputEdit.value;
    taskContent.style.display = "inline";
    inputEdit.style.display = "none";
    editBtn.style.display = "inline";
    saveBtn.style.display = "none";
    cancelBtn.style.display = "none";
  };

  let cancelBtn = document.createElement("button");
  cancelBtn.innerText = "Cancel";
  cancelBtn.className = "cancel-btn";
  cancelBtn.style.display = "none";
  cancelBtn.onclick = () => {
    taskContent.style.display = "inline";
    inputEdit.style.display = "none";
    editBtn.style.display = "inline";
    saveBtn.style.display = "none";
    cancelBtn.style.display = "none";
  };

  let deleteBtn = document.createElement("button");
  deleteBtn.innerText = "Delete";
  deleteBtn.className = "delete-btn";
  deleteBtn.onclick = () => {
    li.remove();
  };

  btnContainer.append(editBtn, saveBtn, cancelBtn, deleteBtn);
  li.append(taskContent, inputEdit, btnContainer);
  document.getElementById("taskList").appendChild(li);

  document.getElementById("taskInput").value = "";
}
